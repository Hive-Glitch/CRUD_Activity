<?php
require 'config/config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$user = ['Firstname'=>'','Lastname'=>'','Middlename'=>'','Birthdate'=>'','Gender'=>'','Email'=>''];
$selectedCourses = [];

if ($id > 0) {
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE user_ID = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $found = $stmt->get_result()->fetch_assoc();
    if (!$found) redirect('index.php');
    $user = $found;

    $stmt = $mysqli->prepare("SELECT course_ID FROM user_course WHERE user_ID = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) $selectedCourses[] = (int)$row['course_ID'];
}

$courses = $mysqli->query("SELECT * FROM course WHERE status='on' ORDER BY course_code");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $id ? 'Edit' : 'Add' ?> User</title>
<style>
body{font-family:Arial,sans-serif;background:#f5f5f5;color:#333;margin:0;padding:30px;font-size:14px;}
h1{font-size:20px;margin:0 0 20px;}
a{color:#0056b3;text-decoration:none;}
a:hover{text-decoration:underline;}
.topnav{margin-bottom:20px;}
.topnav a{margin-right:15px;}
.box{background:#fff;border:1px solid #ccc;padding:20px;max-width:600px;}
label{display:block;margin-bottom:12px;}
label span{display:block;margin-bottom:4px;font-weight:bold;font-size:13px;}
label input,label select{width:100%;padding:6px;border:1px solid #ccc;box-sizing:border-box;}
fieldset{border:1px solid #ccc;padding:12px;margin:12px 0;}
legend{font-weight:bold;font-size:13px;padding:0 4px;}
.checkitem{display:block;margin-bottom:6px;font-weight:normal;}
.checkitem input{width:auto;margin-right:6px;}
.buttons{margin-top:15px;}
.buttons button{padding:7px 16px;background:#0056b3;color:#fff;border:none;cursor:pointer;margin-right:8px;}
.buttons a{padding:7px 16px;border:1px solid #ccc;color:#333;display:inline-block;}
.error{background:#fee;border:1px solid #fcc;color:#900;padding:8px;margin-bottom:15px;}
</style>
</head>
<body>

<div class="topnav">
    <a href="index.php">Users</a>
    <a href="course.php">Courses</a>
</div>

<h1><?= $id ? 'Edit User' : 'Add User' ?></h1>

<?php if (!empty($_GET['error'])): ?>
    <div class="error"><?= e($_GET['error']) ?></div>
<?php endif; ?>

<form method="post" action="save.php" class="box">
    <input type="hidden" name="id" value="<?= e($id) ?>">

    <label><span>First Name *</span>
        <input type="text" name="Firstname" required value="<?= e($user['Firstname']) ?>">
    </label>

    <label><span>Last Name *</span>
        <input type="text" name="Lastname" required value="<?= e($user['Lastname']) ?>">
    </label>

    <label><span>Middle Name</span>
        <input type="text" name="Middlename" value="<?= e($user['Middlename']) ?>">
    </label>

    <label><span>Birthdate *</span>
        <input type="date" name="Birthdate" required value="<?= e($user['Birthdate']) ?>">
    </label>

    <label><span>Gender *</span>
        <select name="Gender" required>
            <option value="">-- Select --</option>
            <option value="M" <?= $user['Gender']==='M'?'selected':'' ?>>Male</option>
            <option value="F" <?= $user['Gender']==='F'?'selected':'' ?>>Female</option>
        </select>
    </label>

    <label><span>Email *</span>
        <input type="email" name="Email" required value="<?= e($user['Email']) ?>">
    </label>

    <fieldset>
        <legend>Courses</legend>
        <?php if ($courses->num_rows === 0): ?>
            <p>No active courses. <a href="course.php">Add one</a>.</p>
        <?php endif; ?>
        <?php while ($c = $courses->fetch_assoc()): ?>
            <label class="checkitem">
                <input type="checkbox" name="courses[]" value="<?= e($c['Course_ID']) ?>"
                    <?= in_array((int)$c['Course_ID'], $selectedCourses, true) ? 'checked' : '' ?>>
                <?= e($c['course_code']) ?> - <?= e($c['name']) ?>
            </label>
        <?php endwhile; ?>
    </fieldset>

    <div class="buttons">
        <button type="submit"><?= $id ? 'Update' : 'Save' ?></button>
        <a href="index.php">Cancel</a>
    </div>
</form>

</body>
</html>