<?php
require 'config/config.php';

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $stmt = $mysqli->prepare("DELETE FROM users WHERE user_ID=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
}
redirect('index.php');