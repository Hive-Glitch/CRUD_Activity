<?php
require 'config/config.php';

$search = trim($_GET['search'] ?? '');
$gender = trim($_GET['gender'] ?? '');
$from   = trim($_GET['from']   ?? '');
$to     = trim($_GET['to']     ?? '');

$where = []; $params = []; $types = '';

if ($search !== '') {
    $where[] = "(u.Firstname LIKE ? OR u.Lastname LIKE ? OR u.Middlename LIKE ?
                 OR c.description LIKE ? OR c.course_code LIKE ?)";
    $like = "%$search%";
    for ($i = 0; $i < 5; $i++) { $params[] = $like; $types .= 's'; }
}
if ($gender !== '') { $where[] = "u.Gender = ?";              $params[] = $gender; $types .= 's'; }
if ($from   !== '') { $where[] = "DATE(u.date_created) >= ?"; $params[] = $from;   $types .= 's'; }
if ($to     !== '') { $where[] = "DATE(u.date_created) <= ?"; $params[] = $to;     $types .= 's'; }

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "
SELECT u.user_ID, u.Firstname, u.Lastname, u.Middlename,
       u.Birthdate, u.Gender, u.Email, u.date_created,
       GROUP_CONCAT(DISTINCT c.course_code ORDER BY c.course_code SEPARATOR ', ') AS course_codes,
       GROUP_CONCAT(DISTINCT c.name        ORDER BY c.name        SEPARATOR ', ') AS course_names
FROM users u
LEFT JOIN user_course uc ON uc.user_ID  = u.user_ID
LEFT JOIN course      c  ON c.Course_ID = uc.course_ID
$whereSql
GROUP BY u.user_ID
ORDER BY u.user_ID DESC
";
$stmt = $mysqli->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Users</title>
<style>
body{font-family:Arial,sans-serif;background:#f5f5f5;color:#333;margin:0;padding:30px;font-size:14px;}
h1{font-size:20px;margin:0 0 20px;}
a{color:#0056b3;text-decoration:none;}
a:hover{text-decoration:underline;}
.topnav{margin-bottom:20px;}
.topnav a{margin-right:15px;}
.filters{background:#fff;border:1px solid #ccc;padding:10px;margin-bottom:20px;}
.filters input,.filters select{padding:5px;margin-right:5px;border:1px solid #ccc;}
.filters input[type=text]{width:200px;}
.filters button{padding:5px 12px;background:#0056b3;color:#fff;border:none;cursor:pointer;}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #ccc;}
th,td{padding:8px 10px;border-bottom:1px solid #ddd;text-align:left;font-size:13px;}
th{background:#eee;font-weight:bold;}
tr:hover td{background:#f9f9f9;}
.empty{text-align:center;color:#888;padding:20px;}
.actions{white-space:nowrap;}
.actions a{margin-right:8px;font-size:13px;}
.add-btn{display:inline-block;background:#0056b3;color:#fff;padding:6px 12px;
         margin-bottom:15px;}
.add-btn:hover{background:#004494;text-decoration:none;}
</style>
</head>
<body>

<div class="topnav">
    <a href="index.php"><strong>Users</strong></a>
    <a href="course.php">Courses</a>
</div>

<h1>Registered Users</h1>

<a href="form.php" class="add-btn">Add User</a>

<form method="get" action="index.php" class="filters">
    <input type="text" name="search" placeholder="Search..." value="<?= e($search) ?>">
    <select name="gender">
        <option value="">Gender</option>
        <option value="M" <?= $gender==='M'?'selected':'' ?>>Male</option>
        <option value="F" <?= $gender==='F'?'selected':'' ?>>Female</option>
    </select>
    <input type="date" name="from" value="<?= e($from) ?>">
    <input type="date" name="to"   value="<?= e($to) ?>">
    <button type="submit">Filter</button>
    <a href="index.php" style="margin-left:8px;">Reset</a>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Birthdate</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Courses</th>
            <th>Date Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($result->num_rows === 0): ?>
        <tr><td colspan="8" class="empty">No users found.</td></tr>
    <?php else: ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= e($row['user_ID']) ?></td>
                <td><?= e($row['Lastname'] . ', ' . $row['Firstname']) ?>
                    <?= $row['Middlename'] ? ' ' . e($row['Middlename']) : '' ?></td>
                <td><?= e($row['Birthdate']) ?></td>
                <td><?= $row['Gender']==='M' ? 'Male' : 'Female' ?></td>
                <td><?= e($row['Email']) ?></td>
                <td><?= $row['course_codes'] ? e($row['course_codes']) : '-' ?></td>
                <td><?= e($row['date_created']) ?></td>
                <td class="actions">
                    <a href="form.php?id=<?= e($row['user_ID']) ?>">Edit</a>
                    <a href="delete.php?id=<?= e($row['user_ID']) ?>"
                       onclick="return confirm('Delete this user?');">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php endif; ?>
    </tbody>
</table>

</body>
</html>