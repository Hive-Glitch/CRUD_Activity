<?php
require 'config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php');

$id         = (int)($_POST['id'] ?? 0);
$Firstname  = trim($_POST['Firstname']  ?? '');
$Lastname   = trim($_POST['Lastname']   ?? '');
$Middlename = trim($_POST['Middlename'] ?? '');
$Birthdate  = trim($_POST['Birthdate']  ?? '');
$Gender     = trim($_POST['Gender']     ?? '');
$Email      = trim($_POST['Email']      ?? '');
$courses    = $_POST['courses'] ?? [];

$errors = [];
if ($Firstname === '') $errors[] = 'First name is required.';
if ($Lastname  === '') $errors[] = 'Last name is required.';
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $Birthdate)) $errors[] = 'Valid birthdate required.';
if (!in_array($Gender, ['M','F'], true)) $errors[] = 'Gender is required.';
if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email.';

if (!$errors) {
    if ($id > 0) {
        $stmt = $mysqli->prepare("SELECT user_ID FROM users WHERE LOWER(Email)=LOWER(?) AND user_ID<>?");
        $stmt->bind_param('si', $Email, $id);
    } else {
        $stmt = $mysqli->prepare("SELECT user_ID FROM users WHERE LOWER(Email)=LOWER(?)");
        $stmt->bind_param('s', $Email);
    }
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0)
        $errors[] = 'Email already exists.';
}

if ($errors) {
    $q = ($id > 0 ? "id=$id&" : '') . 'error=' . urlencode(implode(' ', $errors));
    redirect("form.php?$q");
}

if ($id > 0) {
    $stmt = $mysqli->prepare(
        "UPDATE users SET Firstname=?, Lastname=?, Middlename=?, Birthdate=?, Gender=?, Email=?
         WHERE user_ID=?"
    );
    $stmt->bind_param('ssssssi', $Firstname, $Lastname, $Middlename, $Birthdate, $Gender, $Email, $id);
    $stmt->execute();
} else {
    $stmt = $mysqli->prepare(
        "INSERT INTO users (Firstname, Lastname, Middlename, Birthdate, Gender, Email)
         VALUES (?,?,?,?,?,?)"
    );
    $stmt->bind_param('ssssss', $Firstname, $Lastname, $Middlename, $Birthdate, $Gender, $Email);
    $stmt->execute();
    $id = $mysqli->insert_id;
}

$mysqli->begin_transaction();
try {
    $del = $mysqli->prepare("DELETE FROM user_course WHERE user_ID=?");
    $del->bind_param('i', $id);
    $del->execute();

    if (!empty($courses)) {
        $ins = $mysqli->prepare("INSERT INTO user_course (user_ID, course_ID) VALUES (?,?)");
        foreach ($courses as $cid) {
            $cid = (int)$cid;
            if ($cid > 0) { $ins->bind_param('ii', $id, $cid); $ins->execute(); }
        }
    }
    $mysqli->commit();
} catch (Throwable $t) {
    $mysqli->rollback();
    die('Save failed: ' . $t->getMessage());
}

redirect('index.php');