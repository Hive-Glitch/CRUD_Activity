<?php
require 'config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $code = strtoupper(trim($_POST['course_code'] ?? ''));
    $stat = ($_POST['status'] ?? 'on') === 'off' ? 'off' : 'on';

    if ($name && $code) {
        $stmt = $mysqli->prepare(
            "INSERT INTO course (name, description, course_code, status) VALUES (?,?,?,?)"
        );
        $stmt->bind_param('ssss', $name, $desc, $code, $stat);
        try { $stmt->execute(); } catch (Throwable $t) {}
        redirect('course.php');
    }
}
$courses = $mysqli->query("SELECT * FROM course ORDER BY course_code");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Courses</title>
<style>
body{font-family:Arial,sans-serif;background:#f5f5f5;color:#333;margin:0;padding:30px;font-size:14px;}
h1{font-size:20px;margin:0 0 20px;}
a{color:#0056b3;text-decoration:none;}
a:hover{text-decoration:underline;}
.topnav{margin-bottom:20px;}
.topnav a{margin-right:15px;}
.filters{background:#fff;border:1px solid #ccc;padding:10px;margin-bottom:20px;}
.filters input,.filters select{padding:5px;margin-right:5px;border:1px solid #ccc;}
.filters button{padding:5px 12px;background:#0056b3;color:#fff;border:none;cursor:pointer;}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #ccc;}
th,td{padding:8px 10px;border-bottom:1px solid #ddd;text-align:left;font-size:13px;}
th{background:#eee;font-weight:bold;}
tr:hover td{background:#f9f9f9;}
</style>
</head>
<body>

<div class="topnav">
    <a href="index.php">Users</a>
    <a href="course.php"><strong>Courses</strong></a>
</div>

<h1>Courses</h1>

<form method="post" class="filters">
    <input type="text" name="name" placeholder="Name" required>
    <input type="text" name="description" placeholder="Description">
    <input type="text" name="course_code" placeholder="Code" required>
    <select name="status">
        <option value="on">on</option>
        <option value="off">off</option>
    </select>
    <button type="submit">Add</button>
</form>

<table>
    <thead>
        <tr><th>ID</th><th>Code</th><th>Name</th><th>Description</th>
            <th>Status</th><th>Date Created</th></tr>
    </thead>
    <tbody>
    <?php while ($c = $courses->fetch_assoc()): ?>
        <tr>
            <td><?= e($c['Course_ID']) ?></td>
            <td><?= e($c['course_code']) ?></td>
            <td><?= e($c['name']) ?></td>
            <td><?= e($c['description']) ?></td>
            <td><?= e($c['status']) ?></td>
            <td><?= e($c['date_created']) ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>